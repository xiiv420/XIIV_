#include<stdio.h>
#include"SDL/SDL.h"
#include<SDL/SDL_image.h>
#include<SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <time.h>
#include "fonction.h"
#include <string.h>

#define NUMMM_FRAMES 9

void afficherAide(SDL_Surface *screen, TTF_Font *font, SDL_Color color) {
    const char *instructions[] = {
        "Touches joueur 1 : ZQSD",
        "Touches joueur 2 : Fleches",
        "1 ou 2 : Changer de niveau",
        "H : Afficher / Cacher aide",
        "x : Quitter"
    };

    SDL_Rect pos = {220, 200};
    for (int i = 0; i < 5; ++i) {
        SDL_Surface *text = TTF_RenderText_Solid(font, instructions[i], color);
        SDL_BlitSurface(text, NULL, screen, &pos);
        pos.y += 30;
        SDL_FreeSurface(text);
    }
}
void afficher_temps(SDL_Surface* ecran, TTF_Font* font) {
    // Récupère le temps écoulé depuis le début du jeu en millisecondes
    Uint32 temps_ecoule = SDL_GetTicks();
    
    // Convertit en secondes, minutes et heures
    int secondes = (temps_ecoule / 1000) % 60;
    int minutes = (temps_ecoule / (1000 * 60)) % 60;
    int heures = (temps_ecoule / (1000 * 60 * 60)) % 24;
    
    // Crée une chaîne de caractères pour afficher le temps
    char temps_affichage[9];
    snprintf(temps_affichage, sizeof(temps_affichage), "%02d:%02d:%02d", heures, minutes, secondes);
    
    // Crée une surface pour afficher le texte
    SDL_Color couleur = {255, 255, 255}; // Blanc
    SDL_Surface* texte_surface = TTF_RenderText_Solid(font, temps_affichage, couleur);
    
    if (texte_surface != NULL) {
        // Affiche le texte sur l'écran
	SDL_Rect position = {600, 10}; // Position à l'écran (en haut à droite)
        SDL_BlitSurface(texte_surface, NULL, ecran, &position);
        
        // Libère la surface du texte après affichage
        SDL_FreeSurface(texte_surface);
    }
}


int init_animation(struct Animation* anim) {
    char filename[50];
    for (int i = 0; i < NUMMM_FRAMES; ++i) {
        // Create filename for each frame
        snprintf(filename, sizeof(filename), "animation2/background%d.png", i);

        
        anim->anim[i] = IMG_Load(filename);
        if (!anim->anim[i]) {
            printf("Error loading frame %d: %s\n", i, SDL_GetError());
            return 0;
        }
    }
    return 1; 
}

// Function to display animation frames
void afficher_animation(struct Animation anim, SDL_Surface* screen) {
    static int i = 0; 

    
    SDL_BlitSurface(anim.anim[i], NULL, screen, &anim.pos);

    
    i++;

    
    if (i == NUMMM_FRAMES)
        i = 0;
}

// Function to free resources used by animation frames
void liberer_animation(struct Animation* anim) {
    for (int i = 0; i < NUMMM_FRAMES; ++i) {
        SDL_FreeSurface(anim->anim[i]);
    }
}

void init_minimap(Minimap* m) {
    
    m->mini_image = IMG_Load("mini.jpg");
    m->mini_position.x = 0; 
    m->mini_position.y = 0;
    m->mini_position.w = 180;
    m->mini_position.h = 90;
    
   
    m->player_image = IMG_Load("jou.png");
    m->player_position.x = 250;
    m->player_position.y = 10;
    m->minimap_player_position.x = m->mini_position.x + m->player_position.x; 
    m->minimap_player_position.y = m->mini_position.y + m->player_position.y;
   
}

void MAJMinimap(SDL_Rect posJoueur,  Minimap * m, SDL_Rect camera, int redimensionnement)
{
    SDL_Rect posJoueurABS;
    posJoueurABS.x = 0;
    posJoueurABS.y = 0;
    posJoueurABS.x = posJoueur.x + camera.x;
    posJoueurABS.y = posJoueur.y + camera.y;
    m->minimap_player_position.x = (posJoueurABS.x * redimensionnement/100) + m->mini_position.x;
    m->minimap_player_position.y = (posJoueurABS.y * redimensionnement/100) + m->mini_position.y;
} 

void afficher_minimap(Minimap m, SDL_Surface* screen) {
    
    SDL_BlitSurface(m.mini_image, NULL, screen, &m.mini_position);
    
    SDL_BlitSurface(m.player_image, NULL, screen, &m.minimap_player_position); 
    
}
void liberer_minimap(Minimap* m) {
    
    SDL_FreeSurface(m->mini_image);
    SDL_FreeSurface(m->player_image);
}

SDL_Color GetPixel(SDL_Surface* pSurface, int x, int y) {
    SDL_Color color;
    Uint32 col = 0;
    char* pPosition = (char*) pSurface->pixels;
    pPosition += (pSurface->pitch * y);
    pPosition += (pSurface->format->BytesPerPixel * x);
    memcpy(&col, pPosition, pSurface->format->BytesPerPixel);
    SDL_GetRGB(col, pSurface->format, &color.r, &color.g, &color.b);
    return color;
}  


int collisionPP(SDL_Rect player_pos, SDL_Surface* background) {
   
    int posX[8] = {player_pos.x, player_pos.x + player_pos.w / 2, player_pos.x + player_pos.w, player_pos.x, player_pos.x, player_pos.x + player_pos.w / 2, player_pos.x + player_pos.w, player_pos.x + player_pos.w};
    int posY[8] = {player_pos.y, player_pos.y, player_pos.y, player_pos.y + player_pos.h / 2, player_pos.y + player_pos.h, player_pos.y + player_pos.h, player_pos.y + player_pos.h, player_pos.y + player_pos.h / 2};

    
    for (int i = 0; i < 8; i++) {
        SDL_Color pixelColor = GetPixel(background, posX[i], posY[i]);
        if (pixelColor.r == 255 && pixelColor.g == 255 && pixelColor.b == 255) {
            
            return 1;
        }
 	if (pixelColor.r == 0 && pixelColor.g == 0 && pixelColor.b == 0) {
            
            return 2;
        }
    }

    
    return 0;
} 

// tache blanche

void sauvegarder(SDL_Rect player_position, Minimap m, char *nomfichier) {
    FILE* fichier = fopen(nomfichier, "w");
    if (fichier != NULL) {
        fprintf(fichier, "%d %d %d %d %d %d %d %d %d %d %d %d\n",
            player_position.x, player_position.y,
            m.mini_position.x, m.mini_position.y,
            m.mini_position.w, m.mini_position.h,
            m.minimap_player_position.x, m.minimap_player_position.y,
            m.player_position.x, m.player_position.y,
            m.player_position.w, m.player_position.h);
        fclose(fichier);
    } else {
        printf("Erreur lors de l'ouverture du fichier.");
    }
}

void charger(SDL_Rect *player_position, Minimap *m, char *nomfichier) {
    FILE* fichier = fopen(nomfichier, "r");
    if (fichier != NULL) {
        Sint16 x, y; // Declare x and y variables
        fscanf(fichier, "%hd %hd %hd %hd %hd %hd %hd %hd %hd %hd %hd %hd",
               &x, &y,
               &m->mini_position.x, &m->mini_position.y,
               &m->mini_position.w, &m->mini_position.h,
               &m->minimap_player_position.x, &m->minimap_player_position.y,
               &m->player_position.x, &m->player_position.y,
               &m->player_position.w, &m->player_position.h);

        player_position->x = x;
        player_position->y = y;

        fclose(fichier);
    } else {
        printf("Erreur lors de l'ouverture du fichier.");
    }
}

//integration menu


void init_menu(Menu *m){
m->bg_principal= IMG_Load("1920x1080/1.jpg");
if(m->bg_principal==NULL){
       printf("error load bg_principale");
   }

m->jouer_btn[0]=IMG_Load("menu principale/start.png");
m->jouer_btn[1]=IMG_Load("menu principale/startr.png");

m->option_btn[0]=IMG_Load("menu principale/setting.png");
m->option_btn[1]=IMG_Load("menu principale/settingr.png");

m->meilleur_btn[0]=IMG_Load("menu principale/best.png");
m->meilleur_btn[1]=IMG_Load("menu principale/bestr.png");

m->histoire_btn[0]=IMG_Load("menu principale/exit.png");
m->histoire_btn[1]=IMG_Load("menu principale/exitr.png");

m->quit_btn[0]=IMG_Load("menu principale/exit.png");
m->quit_btn[1]=IMG_Load("menu principale/exitr.png");


m->pos_btn_jouer.x=(1920/2)-(m->jouer_btn[0]->w/2);
m->pos_btn_jouer.y=100;
m->pos_btn_jouer.w=m->jouer_btn[0]->w;
m->pos_btn_jouer.h=m->jouer_btn[0]->h;

m->pos_btn_option.x=(1920/2)-(m->option_btn[0]->w/2);
m->pos_btn_option.y=200;
m->pos_btn_option.w=m->option_btn[0]->w;
m->pos_btn_option.h=m->option_btn[0]->h;

m->pos_btn_meilleur.x=(1920/2)-(m->meilleur_btn[0]->w/2);
m->pos_btn_meilleur.y=300;
m->pos_btn_meilleur.w=m->meilleur_btn[0]->w;
m->pos_btn_meilleur.h=m->meilleur_btn[0]->h;


m->pos_btn_histoire.x=(1920/2)-(m->histoire_btn[0]->w/2);
m->pos_btn_histoire.y=400;
m->pos_btn_histoire.w=m->histoire_btn[0]->w;
m->pos_btn_histoire.h=m->histoire_btn[0]->h;


m->pos_btn_quit.x=(1920/2)-(m->quit_btn[0]->w/2);
m->pos_btn_quit.y=500;
m->pos_btn_quit.w=m->quit_btn[0]->w;
m->pos_btn_quit.h=m->quit_btn[0]->h;






//musicmenuprincipale
m->background_music=Mix_LoadMUS("Density & Time - MAZE  NO COPYRIGHT 8-bit Music.mp3");
if(m->background_music==NULL)
  {
    printf("error load music \n");
  }
else{
 Mix_PlayMusic(m->background_music,-1);
}

m->arial=TTF_OpenFont("font/Pixel-Regular.ttf",40);
m->textColor.r=255;
m->textColor.g=0;
m->textColor.b=0;
m->titreJeu=TTF_RenderText_Solid(m->arial,"THE REBIRTH",m->textColor);
m->posTitre.x=1500;
m->posTitre.y=220;
m->logo=IMG_Load("menu principale/logo.png");
if (m->logo==NULL){printf("error load logo \n");

}
m->posLogo.x=1590;
m->posLogo.y=30;
m->son_btn_selecter=Mix_LoadWAV("2038.wav");


m->bg_option=IMG_Load("1920x1080/2.jpg");
m->option_plus[0]=IMG_Load("option/increase.png");
m->option_plus[1]=IMG_Load("option/increaser.png");
m->option_moin[0]=IMG_Load("option/decrease.png");
m->option_moin[1]=IMG_Load("option/decreaser.png");
m->option_retour[0]=IMG_Load("option/back.png");
m->option_retour[1]=IMG_Load("option/backr.png");
m->option_normal[0]=IMG_Load("option/normal.png");
m->option_normal[1]=IMG_Load("option/normalr.png");
m->option_plein[0]=IMG_Load("option/full.png");
m->option_plein[1]=IMG_Load("option/fullr.png");

m->pos_plus.x=967;
m->pos_plus.y=320;
m->pos_plus.w=m->option_plus[0]->w;
m->pos_plus.h=m->option_plus[0]->h;

m->pos_moin.x=1372;
m->pos_moin.y=320;
m->pos_moin.w=m->option_moin[0]->w;
m->pos_moin.h=m->option_moin[0]->h;

m->pos_normal.x=967;
m->pos_normal.y=550;
m->pos_normal.w=m->option_normal[0]->w;
m->pos_normal.h=m->option_normal[0]->h;

m->pos_plein.x=1372;
m->pos_plein.y=550;
m->pos_plein.w=m->option_plein[0]->w;
m->pos_plein.h=m->option_plein[0]->h;

m->pos_retour.x=1384;
m->pos_retour.y=756;
m->pos_retour.w=m->option_retour[0]->w;
m->pos_retour.h=m->option_retour[0]->h;


m->volume_music=50;
Mix_VolumeMusic(m->volume_music);

m->etat_plein_screen=0;

//sousmenu sauvegarde
m->bg_sauvegarde=IMG_Load("1920x1080/3.jpg");
m->btn_oui[0]=IMG_Load("sauvegardechargement/yesf.png");
m->btn_oui[1]=IMG_Load("sauvegardechargement/yesfr.png");

m->btn_non[0]=IMG_Load("sauvegardechargement/nof.png");
m->btn_non[1]=IMG_Load("sauvegardechargement/nofr.png");

m->btn_charger[0]=IMG_Load("sauvegardechargement/load.png");
m->btn_charger[1]=IMG_Load("sauvegardechargement/loadr.png");

m->btn_nouvelle[0]=IMG_Load("sauvegardechargement/new.png");
m->btn_nouvelle[1]=IMG_Load("sauvegardechargement/newr.png");


m->pos_btn_charger.x=970;
m->pos_btn_charger.y=402;
m->pos_btn_charger.w=m->btn_charger[0]->w;
m->pos_btn_charger.h=m->btn_charger[0]->h;

m->pos_btn_nouvelle.x=970;
m->pos_btn_nouvelle.y=522;
m->pos_btn_nouvelle.w=m->btn_nouvelle[0]->w;
m->pos_btn_nouvelle.h=m->btn_nouvelle[0]->h;

m->pos_btn_oui.x=716;
m->pos_btn_oui.y=565;
m->pos_btn_oui.w=m->btn_oui[0]->w;
m->pos_btn_oui.h=m->btn_oui[0]->h;

m->pos_btn_non.x=1013;
m->pos_btn_non.y=565;
m->pos_btn_non.w=m->btn_non[0]->w;
m->pos_btn_non.h=m->btn_non[0]->h;





m->num_page_sauv=0;


m->num_page_sauv=0;
m->etat_btn_oui=0;
m->etat_btn_non=0;
m->etat_btn_charger=0;
m->etat_btn_nouvelle=0;







m->textSauvegarde=TTF_RenderText_Solid(m->arial,"DO YOU WANT TO SAVE YOUR GAME ?",m->textColor);

m->PosTextSauv.x=(1920/2)-(m->textSauvegarde->w/2);
m->PosTextSauv.y=350;



//joueur
m->bg_joueur=IMG_Load("1920x1080/4.jpg");
m->btn_mono[0]=IMG_Load("joueur/single.png");
m->btn_mono[1]=IMG_Load("joueur/singler.png");


m->btn_multi[0]=IMG_Load("joueur/multin.png");
m->btn_multi[1]=IMG_Load("joueur/multir.png");


m->btn_avatar1[0]=IMG_Load("joueur/1.png");
m->btn_avatar1[1]=IMG_Load("joueur/1.png");


m->btn_avatar2[0]=IMG_Load("joueur/2.png");
m->btn_avatar2[1]=IMG_Load("joueur/2.png");


m->btn_input1[0]=IMG_Load("joueur/flechb.png");
m->btn_input1[1]=IMG_Load("joueur/gr.png");

m->btn_input2[0]=IMG_Load("joueur/dr.png");
m->btn_input2[1]=IMG_Load("joueur/drr.png");

m->btn_retour[0]=IMG_Load("joueur/back.png");
m->btn_retour[1]=IMG_Load("joueur/backr.png");


m->btn_valider[0]=IMG_Load("joueur/nextn.png");
m->btn_valider[1]=IMG_Load("joueur/next.png");


m->pos_btn_mono.x=592;
m->pos_btn_mono.y=539;
m->pos_btn_mono.w=m->btn_mono[0]->w;
m->pos_btn_mono.h=m->btn_mono[0]->h;

m->pos_btn_multi.x=1055;
m->pos_btn_multi.y=539;
m->pos_btn_multi.w=m->btn_multi[0]->w;
m->pos_btn_multi.h=m->btn_multi[0]->h;

m->pos_btn_avatar1.x=533;
m->pos_btn_avatar1.y=190;
m->pos_btn_avatar1.w=m->btn_avatar1[0]->w;
m->pos_btn_avatar1.h=m->btn_avatar1[0]->h;

m->pos_btn_avatar2.x=1000;
m->pos_btn_avatar2.y=190;
m->pos_btn_avatar2.w=m->btn_avatar2[0]->w;
m->pos_btn_avatar2.h=m->btn_avatar2[0]->h;


m->pos_btn_input1.x=533;
m->pos_btn_input1.y=390;
m->pos_btn_input1.w=m->btn_input1[0]->w;
m->pos_btn_input1.h=m->btn_input1[0]->h;

m->pos_btn_input2.x=1293;
m->pos_btn_input2.y=390;
m->pos_btn_input2.w=m->btn_input2[0]->w;
m->pos_btn_input2.h=m->btn_input2[0]->h;


m->pos_btn_retour.x=1384;
m->pos_btn_retour.y=756;
m->pos_btn_retour.w=m->btn_retour[0]->w;
m->pos_btn_retour.h=m->btn_retour[0]->h;


m->pos_btn_valider.x=936;
m->pos_btn_valider.y=643;
m->pos_btn_valider.w=m->btn_valider[0]->w;
m->pos_btn_valider.h=m->btn_valider[0]->h;



m->etat_btn_mono=0;
m->etat_btn_multi=0;
m->etat_btn_avatar1=0;
m->etat_btn_avatar2=0;
m->etat_btn_input1=0;
m->etat_btn_input2=0;
m->etat_btn_retour=0;
m->etat_btn_valider=0;


m->num_page_joueur=0;


//meilleur score


m->bg_meilleur=IMG_Load("1920x1080/5.jpg");

m->espace_saisie[0]=IMG_Load("meilleurscore/saisir.jpg");
m->espace_saisie[1]=IMG_Load("meilleurscore/zone.jpg");

m->etoile[0]=IMG_Load("meilleurscore/kalb.png");
m->etoile[1]=IMG_Load("meilleurscore/kalb.png");
m->etoile[2]=IMG_Load("meilleurscore/kalb.png");


m->textNom=TTF_RenderText_Blended(m->arial,"USER NAME",m->textColor);


m->textMeilleur=TTF_RenderText_Blended(m->arial,"BEST SCORE",m->textColor);




m->pos_espace_saisie.x=830;
m->pos_espace_saisie.y=524;
m->pos_espace_saisie.w=m->espace_saisie[0]->w;
m->pos_espace_saisie.h=m->espace_saisie[0]->h;


m->pos_etoile[0].x=342;
m->pos_etoile[0].y=276;
m->pos_etoile[0].w=m->etoile[0]->w;
m->pos_etoile[0].h=m->etoile[0]->h;


m->pos_etoile[1].x=342;
m->pos_etoile[1].y=495;
m->pos_etoile[1].w=m->etoile[1]->w;
m->pos_etoile[1].h=m->etoile[1]->h;


m->pos_etoile[2].x=342;
m->pos_etoile[2].y=703;
m->pos_etoile[2].w=m->etoile[2]->w;
m->pos_etoile[2].h=m->etoile[2]->h;


m->pos_meilleur.x=1920/2-(m->textMeilleur->w/2);
m->pos_meilleur.y=130;
m->pos_meilleur.w=m->textMeilleur->w;
m->pos_meilleur.h=m->textMeilleur->h;

m->pos_nom.x=1920/2-(m->textNom->w/2);
m->pos_nom.y=429;
m->pos_nom.w=m->textNom->w;
m->pos_nom.h=m->textNom->h;



m->num_page_meilleur=0;
m->etat_espace_saisie=0;
m->espace_saisie_actif=0;

//text




strcpy(m->nom_joueur,"tache-lik");

m->surface_nom= TTF_RenderText_Blended(m->arial,m->nom_joueur,m->textColor);

m->pos_nom_joueur.x=m->pos_espace_saisie.x+10;
m->pos_nom_joueur.y=m->pos_espace_saisie.y+10;



}





void afficher_menu(Menu m,SDL_Surface *screen){
    SDL_BlitSurface(m.bg_principal,NULL,screen,NULL);
    
    if (collision_avec_souris(m.pos_btn_jouer)==0 && m.btn_selectionner !=1){SDL_BlitSurface(m.jouer_btn[0],NULL,screen,&m.pos_btn_jouer);
         }
    else{
         SDL_BlitSurface(m.jouer_btn[1],NULL,screen,&m.pos_btn_jouer);
         }
if (collision_avec_souris(m.pos_btn_option)==0 && m.btn_selectionner !=2){
    SDL_BlitSurface(m.option_btn[0],NULL,screen,&m.pos_btn_option);
}
    else{
         SDL_BlitSurface(m.option_btn[1],NULL,screen,&m.pos_btn_option);
         }
if (collision_avec_souris(m.pos_btn_meilleur)==0 && m.btn_selectionner !=3){
    SDL_BlitSurface(m.meilleur_btn[0],NULL,screen,&m.pos_btn_meilleur);
}
    else{
         SDL_BlitSurface(m.meilleur_btn[1],NULL,screen,&m.pos_btn_meilleur);
         }
if (collision_avec_souris(m.pos_btn_histoire)==0 && m.btn_selectionner !=4){
    SDL_BlitSurface(m.histoire_btn[0],NULL,screen,&m.pos_btn_histoire);
}
    else{
         SDL_BlitSurface(m.histoire_btn[1],NULL,screen,&m.pos_btn_histoire);
         }
if (collision_avec_souris(m.pos_btn_quit)==0 && m.btn_selectionner !=5){
    SDL_BlitSurface(m.quit_btn[0],NULL,screen,&m.pos_btn_quit);
    }
    else{
         SDL_BlitSurface(m.quit_btn[1],NULL,screen,&m.pos_btn_quit);
         }

SDL_BlitSurface(m.titreJeu,NULL,screen,&m.posTitre);
SDL_BlitSurface(m.logo,NULL,screen,&m.posLogo);

}


void afficher_menu_option(Menu m,SDL_Surface *screen){
    SDL_BlitSurface(m.bg_option,NULL,screen,NULL);
    
    if (collision_avec_souris(m.pos_moin)==1 ){SDL_BlitSurface(m.option_moin[1],NULL,screen,&m.pos_moin);
         }
    else{
         SDL_BlitSurface(m.option_moin[0],NULL,screen,&m.pos_moin);
         }
    if (collision_avec_souris(m.pos_plus)==1 ){SDL_BlitSurface(m.option_plus[1],NULL,screen,&m.pos_plus);
         }
    else{
         SDL_BlitSurface(m.option_plus[0],NULL,screen,&m.pos_plus);
         }
     
    if (collision_avec_souris(m.pos_retour)==1 ){SDL_BlitSurface(m.option_retour[1],NULL,screen,&m.pos_retour);
         }
    else{
         SDL_BlitSurface(m.option_retour[0],NULL,screen,&m.pos_retour);
         }
    if (collision_avec_souris(m.pos_normal)==1 ){SDL_BlitSurface(m.option_normal[1],NULL,screen,&m.pos_normal);
         }
    else{
         SDL_BlitSurface(m.option_normal[0],NULL,screen,&m.pos_normal);
         }
    if (collision_avec_souris(m.pos_plein)==1 ){SDL_BlitSurface(m.option_plein[1],NULL,screen,&m.pos_plein);
         }
    else{
         SDL_BlitSurface(m.option_plein[0],NULL,screen,&m.pos_plein);
         }

}


int collision_avec_souris(SDL_Rect pos_btn)
{
   int x_souris,y_souris;
   SDL_GetMouseState(&x_souris,&y_souris);
   if((x_souris > pos_btn.x) && x_souris < (pos_btn.x + pos_btn.w) && y_souris > pos_btn.y && y_souris < pos_btn.y + pos_btn.h)
   {
            
            return 1;
   }

    else{
            
            return 0;
        }

} 







void afficher_menu_sauv(Menu m,SDL_Surface *screen){
              
          SDL_BlitSurface(m.bg_sauvegarde,NULL,screen,NULL);
        if(m.num_page_sauv==0){
                      SDL_BlitSurface(m.textSauvegarde,NULL,screen,&m.PosTextSauv);


 SDL_BlitSurface(m.btn_oui[m.etat_btn_oui],NULL,screen,&m.pos_btn_oui);


SDL_BlitSurface(m.btn_non[m.etat_btn_non],NULL,screen,&m.pos_btn_non);


                    }else{
                            SDL_BlitSurface(m.btn_charger[m.etat_btn_charger],NULL,screen,&m.pos_btn_charger);
SDL_BlitSurface(m.btn_nouvelle[m.etat_btn_nouvelle],NULL,screen,&m.pos_btn_nouvelle);
                            }

   }





























void miseajour_menu(Menu *m){
    if (collision_avec_souris(m->pos_btn_jouer)==1){

         if(m->btn_selectionner !=1)
              Mix_PlayChannel(-1,m->son_btn_selecter,0);

         m->btn_selectionner=1;
    }
    else if(collision_avec_souris(m->pos_btn_option)==1){
       if(m->btn_selectionner !=2)
              Mix_PlayChannel(-1,m->son_btn_selecter,0);
       m->btn_selectionner=2;
       
    }
    else if(collision_avec_souris(m->pos_btn_meilleur)==1){
       if(m->btn_selectionner !=3)
              Mix_PlayChannel(-1,m->son_btn_selecter,0);
       m->btn_selectionner=3;
        
    }
    else if(collision_avec_souris(m->pos_btn_histoire)==1){
       if(m->btn_selectionner !=4)
              Mix_PlayChannel(-1,m->son_btn_selecter,0);
       m->btn_selectionner=4;
       
    }
    else if(collision_avec_souris(m->pos_btn_quit)==1){
       if(m->btn_selectionner !=5)
              Mix_PlayChannel(-1,m->son_btn_selecter,0);
       m->btn_selectionner=5;
        
    }

   //printf("btn selectionner = %d \n",m->btn_selectionner);
}


void miseajour_menu_sauv(Menu *m){

      if(m->num_page_sauv==0){

          if(collision_avec_souris(m->pos_btn_oui)==1){
                      if(m->etat_btn_oui==0)
                            Mix_PlayChannel(-1,m->son_btn_selecter,0);
                      m->etat_btn_oui=1;
             }else{
                      m->etat_btn_oui=0;
                  
                    }

          if(collision_avec_souris(m->pos_btn_non)==1){
                  if(m->etat_btn_non==0)
                            Mix_PlayChannel(-1,m->son_btn_selecter,0);
                  m->etat_btn_non=1;
             }else{
                      m->etat_btn_non=0;
                    }

          }
          else{
           if(collision_avec_souris(m->pos_btn_charger)==1){
                  if(m->etat_btn_charger==0)
                            Mix_PlayChannel(-1,m->son_btn_selecter,0);
                  m->etat_btn_charger=1;
             }else{
                      m->etat_btn_charger=0;
                    }

           if(collision_avec_souris(m->pos_btn_nouvelle)==1){
                  if(m->etat_btn_nouvelle==0)
                            Mix_PlayChannel(-1,m->son_btn_selecter,0);
                  m->etat_btn_nouvelle=1;
             }else{
                      m->etat_btn_nouvelle=0;
                    }
               }
            





}


void afficher_menu_joueur(Menu m,SDL_Surface *screen){


        SDL_BlitSurface(m.bg_joueur,NULL,screen,NULL);
        if(m.num_page_joueur==0){
                     
                                      SDL_BlitSurface(m.btn_mono[m.etat_btn_mono],NULL,screen,&m.pos_btn_mono);


SDL_BlitSurface(m.btn_multi[m.etat_btn_multi],NULL,screen,&m.pos_btn_multi);
SDL_BlitSurface(m.btn_retour[m.etat_btn_retour],NULL,screen,&m.pos_btn_retour);
                               }else{//page avatar input
                                      

                                    SDL_BlitSurface(m.btn_avatar1[m.etat_btn_avatar1],NULL,screen,&m.pos_btn_avatar1);

SDL_BlitSurface(m.btn_avatar2[m.etat_btn_avatar2],NULL,screen,&m.pos_btn_avatar2);

SDL_BlitSurface(m.btn_input1[m.etat_btn_input1],NULL,screen,&m.pos_btn_input1);
SDL_BlitSurface(m.btn_input2[m.etat_btn_input2],NULL,screen,&m.pos_btn_input2);
SDL_BlitSurface(m.btn_retour[m.etat_btn_retour],NULL,screen,&m.pos_btn_retour);
   SDL_BlitSurface(m.btn_valider[m.etat_btn_valider],NULL,screen,&m.pos_btn_valider);                                

   }












}

void miseajour_menu_joueur(Menu *m){


  if(m->num_page_joueur==0){

          if(collision_avec_souris(m->pos_btn_mono)==1){
                      if(m->etat_btn_mono==0)
                            Mix_PlayChannel(-1,m->son_btn_selecter,0);
                      m->etat_btn_mono=1;
             }else{
                      m->etat_btn_mono=0;
                  
                    }
         

           if(collision_avec_souris(m->pos_btn_multi)==1){
                      if(m->etat_btn_multi==0)
                            Mix_PlayChannel(-1,m->son_btn_selecter,0);
                      m->etat_btn_multi=1;
             }else{
                      m->etat_btn_multi=0;
                  
                    }


            

}else{
             if(collision_avec_souris(m->pos_btn_valider)==1){
                      if(m->etat_btn_valider==0)
                            Mix_PlayChannel(-1,m->son_btn_selecter,0);
                      m->etat_btn_valider=1;
             }else{
                      m->etat_btn_valider=0;
                  
                    } 
}


if(collision_avec_souris(m->pos_btn_retour)==1){
                      if(m->etat_btn_retour==0)
                            Mix_PlayChannel(-1,m->son_btn_selecter,0);
                      m->etat_btn_retour=1;
             }else{
                      m->etat_btn_retour=0;
                  
                    }



}




void afficher_menu_meilleur(Menu m,SDL_Surface *screen){



               SDL_BlitSurface(m.bg_meilleur,NULL,screen,NULL);
        if(m.num_page_meilleur==0){
SDL_BlitSurface(m.textNom,NULL,screen,&m.pos_nom);  


                                    SDL_BlitSurface(m.espace_saisie[(m.etat_espace_saisie || m.espace_saisie_actif)],NULL,screen,&m.pos_espace_saisie);



SDL_BlitSurface(m.btn_valider[0],NULL,screen,&m.pos_btn_valider);

               SDL_BlitSurface(m.surface_nom,NULL,screen,&m.pos_nom_joueur);

                                  }else{
 
                                        }
            









}


void miseajour_menu_meilleur(Menu *m){
                          if(collision_avec_souris(m->pos_espace_saisie)==1){
                                        m->etat_espace_saisie=1;
}else{m->etat_espace_saisie=0;}

   




}

void miseajour_nom_joueur(SDL_Event e,Menu *m){




         if (m->etat_espace_saisie==1){


                              if(e.key.keysym.sym >= SDLK_a && e.key.keysym.sym<=SDLK_z ){

                                             char key[2]={e.key.keysym.sym};//'a'

                                             strcat(m->nom_joueur,key);
                                             
                                              m->surface_nom= TTF_RenderText_Blended(m->arial,m->nom_joueur,m->textColor);
                                         }else if (e.key.keysym.sym >= SDLK_0 && e.key.keysym.sym<=SDLK_9){

                                             char key[2]={e.key.keysym.sym};//'a'

                                             strcat(m->nom_joueur,key);
                                             
                                              m->surface_nom= TTF_RenderText_Blended(m->arial,m->nom_joueur,m->textColor);
                                         }else if(e.key.keysym.sym== SDLK_BACKSPACE){


  if(strlen(m->nom_joueur)>0){m->nom_joueur[strlen(m->nom_joueur)-1]='\0';
m->surface_nom= TTF_RenderText_Blended(m->arial,m->nom_joueur,m->textColor);
}

}





                                        }





}



void menu(SDL_Surface* screen) 
{

    SDL_Init( SDL_INIT_VIDEO | SDL_INIT_AUDIO) ;
    screen = SDL_SetVideoMode(1920, 1080,  32,SDL_HWSURFACE | SDL_DOUBLEBUF);
    Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,4096);
    TTF_Init();

    int quitter=0;
    SDL_Event event;
    int indice_screen=0;
    Menu menu;
    init_menu(&menu);
    SDL_Rect player_pos = {600, 350, 0, 0};
    Minimap minimap;
    init_minimap(&minimap);
    while(quitter==0){
    
       switch(indice_screen){
	 case 0:  afficher_menu(menu,screen);
                  SDL_Flip(screen);
                   while (SDL_PollEvent(&event)){

			     switch (event.type)
			 { 
			
				case SDL_QUIT: quitter = 1;
				   break;
                                case SDL_MOUSEBUTTONDOWN:
                                     if (event.button.button==SDL_BUTTON_LEFT){
if(menu.btn_selectionner==5){
  quitter=1;
}
if(menu.btn_selectionner==1){
  indice_screen=3;
}
if(menu.btn_selectionner==2){
  indice_screen=2;
}
if(menu.btn_selectionner==3){
  indice_screen=4;
}
}
				   break;
                               case SDL_KEYDOWN:
                                    if(event.key.keysym.sym==SDLK_DOWN){
                                           menu.btn_selectionner ++;
                                           if(menu.btn_selectionner>5)
                                                menu.btn_selectionner=1;
                                                        
                                        }
                                     if(event.key.keysym.sym==SDLK_UP){
                                           menu.btn_selectionner --;
                                           if(menu.btn_selectionner<1)
                                                menu.btn_selectionner=5;
                                      }
                                     if(event.key.keysym.sym==SDLK_j ||(menu.btn_selectionner==1 && event.key.keysym.sym==SDLK_RETURN)){
                                          indice_screen=1;  
                                          }
                                     if(event.key.keysym.sym==SDLK_o ||(menu.btn_selectionner==2 && event.key.keysym.sym==SDLK_RETURN)){
                                          indice_screen=2;  
                                          }
                                     if(event.key.keysym.sym==SDLK_m ||(menu.btn_selectionner==3 && event.key.keysym.sym==SDLK_RETURN)){
                                          indice_screen=3;  
                                          }
                                   break;
				default:
				   break;
				
			 }



		      }
               miseajour_menu(&menu);
             break;
          case 1://sous menu joueur
              afficher_menu_joueur(menu,screen);
              SDL_Flip(screen);
              while (SDL_PollEvent(&event)){

			     switch (event.type)
			 { 
			
				case SDL_QUIT: quitter = 1;
				   break;
                                case SDL_KEYDOWN:
                                    indice_screen=0;
                                    break;
                                case SDL_MOUSEBUTTONDOWN:
                                    if (event.button.button==SDL_BUTTON_LEFT){
              if(menu.etat_btn_retour==1 && menu.num_page_joueur==0){indice_screen=0;}else if(menu.etat_btn_retour==1 && menu.num_page_joueur==1){menu.num_page_joueur=0;}


              if(menu.etat_btn_mono==1||menu.etat_btn_multi==1){menu.num_page_joueur=1; 

menu.etat_btn_mono=0;
menu.etat_btn_multi=0;
 }
if(collision_avec_souris(menu.pos_btn_avatar1)==1){
menu.etat_btn_avatar1=1;
menu.etat_btn_avatar2=0;
}else if(collision_avec_souris(menu.pos_btn_avatar2)==1){
menu.etat_btn_avatar1=0;
menu.etat_btn_avatar2=1;
}else if(collision_avec_souris(menu.pos_btn_input1)==1){
menu.etat_btn_input1=1;
menu.etat_btn_input2=0;
}else if(collision_avec_souris(menu.pos_btn_input2)==1){
menu.etat_btn_input1=0;
menu.etat_btn_input2=1;
}

if(menu.etat_btn_valider==1){
indice_screen=4;
}

}

                                 break;
                          }
                   }
             miseajour_menu_joueur(&menu);
             break;
          case 2://sous menu option
              afficher_menu_option(menu,screen);
              SDL_Flip(screen);
              while (SDL_PollEvent(&event)){

			     switch (event.type)
			 { 
			
				case SDL_QUIT: quitter = 1;
				   break;
                                
                                case SDL_MOUSEBUTTONDOWN:
                                    if (event.button.button==SDL_BUTTON_LEFT){
                                           if(collision_avec_souris(menu.pos_retour)==1){indice_screen=0;}
if(collision_avec_souris(menu.pos_plus)==1){
menu.volume_music +=10;
if(menu.volume_music>100)
   menu.volume_music=100;
}
if(collision_avec_souris(menu.pos_moin)==1){
menu.volume_music -=10;
if(menu.volume_music<0)
   menu.volume_music=0;
}
if(collision_avec_souris(menu.pos_plein)==1 && menu.etat_plein_screen==0){
     screen = SDL_SetVideoMode(1920, 1080,  32,SDL_HWSURFACE | SDL_DOUBLEBUF |SDL_FULLSCREEN);
menu.etat_plein_screen=1;
}
if(collision_avec_souris(menu.pos_normal)==1 && menu.etat_plein_screen==1){
     screen = SDL_SetVideoMode(1920, 1080,  32,SDL_HWSURFACE | SDL_DOUBLEBUF);
menu.etat_plein_screen=0;
}
printf("le volume =%d \n",menu.volume_music);
                                       }
                                   break;
                          }
                   }
             break;
           
           case 3://sous menu sauv
                  afficher_menu_sauv(menu,screen);
                  SDL_Flip(screen);
                    
                   while (SDL_PollEvent(&event)){

			     switch (event.type)
			 { 
			
				case SDL_QUIT: quitter = 1;
				   break;
                                case SDL_KEYDOWN:
                                    indice_screen=0;
                                    if(event.key.keysym.sym==SDLK_n){
                                                indice_screen=1;
                                                                 }
                                    break;
                                 case SDL_MOUSEBUTTONDOWN:
                                    if (event.button.button==SDL_BUTTON_LEFT){
                                       
                           if(menu.etat_btn_oui==1){menu.num_page_sauv=1;
                                                   }
                                        if(menu.etat_btn_nouvelle==1){
                        charger(&player_pos, &minimap, "savefile.txt");
			game(screen);
						}
                                      }
                                  
                                  break;
                          }
                   }





                   miseajour_menu_sauv(&menu);

   
                   break;
          case 4://meilleur score
                afficher_menu_meilleur(menu,screen);
                SDL_Flip(screen);
               while (SDL_PollEvent(&event)){

			     switch (event.type)
			 { 
			
				case SDL_QUIT: quitter = 1;
				   break;
                                case SDL_MOUSEBUTTONDOWN:
                                        if(event.button.button==SDL_BUTTON_LEFT){
if(menu.etat_espace_saisie==1){
menu.espace_saisie_actif=1;
}else{menu.espace_saisie_actif=0;}printf("etat actif=%d \n",menu.espace_saisie_actif);
}
                                  break;


                                  case SDL_KEYDOWN:
                                        miseajour_nom_joueur(event,&menu);
                                    break;
                                default:
                                   break;
                          }
          }
           miseajour_menu_meilleur(&menu);
            break;
           default:
              break;
                 }
      
    }

    SDL_FreeSurface(screen);
    SDL_Quit();




}

void init_background(Background *b) {
    b->background = IMG_Load("back.jpg");
    if(!b->background) {
        printf("Error loading background: %s\n", SDL_GetError());
        return;
    }
    
    b->camera.x = 0;
    b->camera.y = 0;
    b->camera.w = 1500; // Match your screen width
    b->camera.h = 500;  // Match your screen height
    
    b->pos_background.x = 0;
    b->pos_background.y = 0;
}
void game(SDL_Surface *screen) {
    TTF_Font* font = TTF_OpenFont("/home/roua/Desktop/game/tacheblanche (another copy)/Pixel-Regular.ttf", 24);
    
    SDL_Surface *background = IMG_Load("back.jpg");
    SDL_Surface *backmask = IMG_Load("backmask.jpg");
    SDL_Surface *player = IMG_Load("jou.png");
    
    if (!background || !backmask || !player) {
        printf("Error loading images: %s\n", IMG_GetError());
        return;
    }

    SDL_Rect camera = {0, 0, SCREEN_WIDTH, SCREEN_HEIGHT};
    SDL_Rect player_pos = {
        SCREEN_WIDTH/2,
        SCREEN_HEIGHT/2,
        player->w,
        player->h
    };
    
    Minimap minimap;
    init_minimap(&minimap);
    
    int done = 0;
    int player_speed = 5;
    int show_help = 0;

    while(!done) {
        SDL_Event event;
        while(SDL_PollEvent(&event)) {
            switch(event.type) {
                case SDL_QUIT:
                    done = 1;
                    break;
                case SDL_KEYUP:
                    switch(event.key.keysym.sym) {
			case SDLK_h:
    				show_help = !show_help; // toggle aide
    				break;
                        case SDLK_ESCAPE:
                            done = 1;
                            break;
                        case SDLK_o:
                            menu(screen);
                            sauvegarder(player_pos, minimap, "savefile.txt");
                            break;
                        case SDLK_s:
                            sauvegarder(player_pos, minimap, "savefile.txt");
                            break;
                        case SDLK_c:
                            charger(&player_pos, &minimap, "savefile.txt");
                            break;
                    }
                    break;
            }
        }

        SDL_Rect old_pos = player_pos;
        Uint8 *keystate = SDL_GetKeyState(NULL);
        
        if(keystate[SDLK_LEFT]) {
            player_pos.x -= player_speed;
        }
        if(keystate[SDLK_RIGHT]) {
            player_pos.x += player_speed;
        }
        if(keystate[SDLK_UP]) {
            player_pos.y -= player_speed;
        }
        if(keystate[SDLK_DOWN]) {
            player_pos.y += player_speed;
        }

        // Bounds and collision checking
        if(player_pos.x < 0) player_pos.x = 0;
        if(player_pos.y < 0) player_pos.y = 0;
        if(player_pos.x > background->w - player_pos.w)
            player_pos.x = background->w - player_pos.w;
        if(player_pos.y > background->h - player_pos.h)
            player_pos.y = background->h - player_pos.h;

        if(collisionPP(player_pos, backmask)) {
            player_pos = old_pos;
        }

        // Camera update
        camera.x = player_pos.x - (SCREEN_WIDTH/2);
        camera.y = player_pos.y - (SCREEN_HEIGHT/2);

        // Camera bounds
        if(camera.x < 0) camera.x = 0;
        if(camera.y < 0) camera.y = 0;
        if(camera.x > background->w - SCREEN_WIDTH)
            camera.x = background->w - SCREEN_WIDTH;
        if(camera.y > background->h - SCREEN_HEIGHT)
            camera.y = background->h - SCREEN_HEIGHT;

        // Update and draw
        MAJMinimap(player_pos, &minimap, camera, 20);
        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));

        SDL_Rect dest = {0, 0, 0, 0};
        SDL_BlitSurface(background, &camera, screen, &dest);

        SDL_Rect player_screen_pos = {
            player_pos.x - camera.x,
            player_pos.y - camera.y,
            player_pos.w,
            player_pos.h
        };
        SDL_BlitSurface(player, NULL, screen, &player_screen_pos);
        afficher_minimap(minimap, screen);
	afficher_temps(screen, font);
	if (show_help) {
    		SDL_Color color = {255, 255, 255}; // blanc
    		afficherAide(screen, font, color);
}

        SDL_Flip(screen);
        SDL_Delay(16);
    }

    TTF_CloseFont(font);
    SDL_FreeSurface(background);
    SDL_FreeSurface(backmask);
    SDL_FreeSurface(player);
    liberer_minimap(&minimap);
}














