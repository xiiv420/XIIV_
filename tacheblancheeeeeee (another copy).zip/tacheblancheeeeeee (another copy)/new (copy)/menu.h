#ifndef MENU_H
#define MENU_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
typedef struct {
    SDL_Surface *bg_principal;
    SDL_Surface *jouer_btn[2];
    SDL_Surface *option_btn[2];
    SDL_Surface *meilleur_btn[2];
    SDL_Surface *histoire_btn[2];
    SDL_Surface *quit_btn[2];
    SDL_Rect pos_btn_jouer;
    SDL_Rect pos_btn_option;
    SDL_Rect pos_btn_meilleur;
    SDL_Rect pos_btn_histoire;
    SDL_Rect pos_btn_quit;



    int btn_selectionner;
    Mix_Music *background_music;
    Mix_Chunk *son_btn_selecter;

    SDL_Surface *titreJeu;
    TTF_Font *arial;
    SDL_Color textColor;
    SDL_Rect posTitre;


    SDL_Surface *logo;
    SDL_Rect posLogo;


    //sousmenuoption
    SDL_Surface *bg_option;
    SDL_Surface *option_plus[2];
    SDL_Surface *option_moin[2];
    SDL_Surface *option_retour[2];
    SDL_Surface *option_normal[2];
    SDL_Surface *option_plein[2];

    SDL_Rect pos_plus;
    SDL_Rect pos_moin;
    SDL_Rect pos_normal;
    SDL_Rect pos_plein;
    SDL_Rect pos_retour;


    int volume_music;
    int etat_plein_ecran;

    //sousmenu sauvegarde
    SDL_Surface *bg_sauvegarde;
    SDL_Surface *btn_oui[2];
    SDL_Surface *btn_non[2];
    SDL_Surface *btn_charger[2];
    SDL_Surface *btn_nouvelle[2];
    

    SDL_Rect pos_btn_oui;
    SDL_Rect pos_btn_non;
    SDL_Rect pos_btn_charger;
    SDL_Rect pos_btn_nouvelle;
    

    int num_page_sauv;
    int etat_btn_oui;
    int etat_btn_non;
    int etat_btn_charger;
    int etat_btn_nouvelle;

    SDL_Surface *textSauvegarde;
    SDL_Rect PosTextSauv;


    //sousmenujoueur
    SDL_Surface *bg_joueur;
    SDL_Surface *btn_mono[2];
    SDL_Surface *btn_multi[2];
    SDL_Surface *btn_avatar1[2];
    SDL_Surface *btn_avatar2[2];
    SDL_Surface *btn_input1[2];
    SDL_Surface *btn_input2[2];

    SDL_Surface *btn_retour[2];
    SDL_Surface *btn_valider[2];


    SDL_Rect pos_btn_mono;
    SDL_Rect pos_btn_multi;
    SDL_Rect pos_btn_avatar1;
    SDL_Rect pos_btn_avatar2;
    SDL_Rect pos_btn_input1;
    SDL_Rect pos_btn_input2;
    SDL_Rect pos_btn_retour;
    SDL_Rect pos_btn_valider;

    int etat_btn_mono;
    int etat_btn_multi;
    int etat_btn_avatar1;
    int etat_btn_avatar2;
    int etat_btn_input1;
    int etat_btn_input2;
    int etat_btn_retour;
    int etat_btn_valider;

    int num_page_joueur;

    //meilleurscore
    SDL_Surface *bg_meilleur;
    SDL_Surface *espace_saisie[2];
    SDL_Surface *etoile[3];
    SDL_Surface *textNom;
    SDL_Surface *textMeilleur;    


    SDL_Rect pos_espace_saisie;
    SDL_Rect pos_etoile[3];
    SDL_Rect pos_nom;
    SDL_Rect pos_meilleur;


    int num_page_meilleur;
    int etat_espace_saisie;
    int espace_saisie_actif;


    
    char nom_joueur[25];
    SDL_Surface *surface_nom; 
    SDL_Rect pos_nom_joueur;    


   
} Menu;

void init_menu(Menu *m);
void afficher_menu(Menu m,SDL_Surface *ecran);
void afficher_menu_option(Menu m,SDL_Surface *ecran);
void afficher_menu_sauv(Menu m,SDL_Surface *ecran);
void afficher_menu_joueur(Menu m,SDL_Surface *ecran);
void afficher_menu_meilleur(Menu m,SDL_Surface *ecran);

int collision_avec_souris(SDL_Rect pos_btn);
void miseajour_menu(Menu *m);
void miseajour_menu_sauv(Menu *m);
void miseajour_menu_joueur(Menu *m);
void miseajour_menu_meilleur(Menu *m);


void miseajour_nom_joueur(SDL_Event e,Menu *m);









#endif

