#include "menu.h"
#include <SDL/SDL_image.h>  // Pour utiliser IMG_Load()

// Fonction pour initialiser la minimap
void initialiserMinimap(minimap *m, SDL_Surface *background, SDL_Surface *bonhomme, SDL_Rect positionBackground) {
    m->imageBackground = background;
    m->imageBonhomme = bonhomme;
    m->positionBackground = positionBackground;
    m->positionBonhomme.x = 0;
    m->positionBonhomme.y = 0;
}

// Fonction pour mettre à jour la position du bonhomme dans la minimap
void MAJMinimap(SDL_Rect posJoueur, minimap *m, SDL_Rect camera, int redimensionnement) {
    // Calcul de la position absolue du joueur
    SDL_Rect posJoueurABS;
    posJoueurABS.x = posJoueur.x + camera.x;
    posJoueurABS.y = posJoueur.y + camera.y;

    // Calcul de la position du bonhomme sur la minimap
    m->positionBonhomme.x = posJoueurABS.x * redimensionnement / 100;
    m->positionBonhomme.y = posJoueurABS.y * redimensionnement / 100;
}

// Fonction pour afficher la minimap et le bonhomme miniature
void afficher(minimap m, SDL_Surface *screen) {
    // Affichage de l'image miniature de fond
    SDL_BlitSurface(m.imageBackground, NULL, screen, &m.positionBackground);

    // Affichage du bonhomme miniature (par exemple, un point rouge)
    SDL_FillRect(screen, &m.positionBonhomme, SDL_MapRGB(screen->format, 255, 0, 0));  // Point rouge
}

// Fonction pour libérer la mémoire de la minimap
void Liberer(minimap *m) {
    if (m->imageBackground != NULL) {
        SDL_FreeSurface(m->imageBackground);
    }
    if (m->imageBonhomme != NULL) {
        SDL_FreeSurface(m->imageBonhomme);
    }
}

