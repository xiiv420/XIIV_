#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "menu.h"

// Fonction pour charger une image JPEG avec SDL_image
SDL_Surface* chargerImage(const char *chemin) {
    SDL_Surface* image = IMG_Load(chemin);  // Utilisation de SDL_image pour charger l'image
    if (image == NULL) {
        printf("Erreur de chargement de l'image : %s\n", IMG_GetError());
    }
    return image;
}

int main(int argc, char *argv[]) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("Erreur d'initialisation SDL: %s\n", SDL_GetError());
        return 1;
    }

    if (IMG_Init(IMG_INIT_JPG) == 0) {  
        printf("Erreur d'initialisation de SDL_image : %s\n", IMG_GetError());
        SDL_Quit();
        return 1;
    }

    SDL_Surface *screen = SDL_SetVideoMode(1500, 1100, 32, SDL_SWSURFACE);
    
   
    SDL_Surface *background = chargerImage("back.jpg");  
    SDL_Surface *bonhomme = chargerImage("/home/ahmed/Desktop/,,,/minimap/423541704_1164994044813154_2673524383677852230_n.png");      

    SDL_Rect positionBackground = { 600, 10, 200, 150 };  // Position de la minimap sur l'écran

    minimap m;
    initialiserMinimap(&m, background, bonhomme, positionBackground);

    SDL_Rect posJoueur = { 400, 300, 0, 0 };  // Position du joueur
    SDL_Rect camera = { 0, 0, 0, 0 };  // Position de la caméra

    int continuer = 1;
    while (continuer) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                continuer = 0;
            }
        }

        // Mise à jour de la minimap avec la position du joueur
        MAJMinimap(posJoueur, &m, camera, 20);

        // Affichage de la minimap
        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));  // Nettoyer l'écran
        afficher(m, screen);

        // Actualisation de l'écran
        SDL_Flip(screen);

        SDL_Delay(16);  // Limite à environ 60 FPS
    }

    Liberer(&m);
    SDL_FreeSurface(background);
    SDL_FreeSurface(bonhomme);
    IMG_Quit();  // Libérer SDL_image
    SDL_Quit();
    return 0;
}

