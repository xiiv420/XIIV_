#ifndef MENU_H
#define MENU_H

#include <SDL/SDL.h>

typedef struct {
    SDL_Surface *imageBackground;  // Image miniature du fond
    SDL_Rect positionBackground;   // Position de la minimap sur l'écran
    SDL_Surface *imageBonhomme;    // Image du bonhomme miniature
    SDL_Rect positionBonhomme;     // Position du bonhomme miniature dans la minimap
} minimap;

// Fonction pour initialiser la minimap
void initialiserMinimap(minimap *m, SDL_Surface *background, SDL_Surface *bonhomme, SDL_Rect positionBackground);

// Fonction pour mettre à jour la minimap avec la position du joueur
void MAJMinimap(SDL_Rect posJoueur, minimap *m, SDL_Rect camera, int redimensionnement);

// Fonction pour afficher la minimap
void afficher(minimap m, SDL_Surface *screen);

// Fonction pour libérer la mémoire de la minimap
void Liberer(minimap *m);

#endif

