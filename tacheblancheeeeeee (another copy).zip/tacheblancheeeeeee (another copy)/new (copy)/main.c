#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include"menu.h"

int main() {

    SDL_Init( SDL_INIT_VIDEO | SDL_INIT_AUDIO) ;
    SDL_Surface *ecran;
    ecran = SDL_SetVideoMode(1920, 1080,  32,SDL_HWSURFACE | SDL_DOUBLEBUF);
    Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,4096);
    TTF_Init();

    int quitter=0;
    SDL_Event event;
    int indice_ecran=0;
    Menu menu;
    init_menu(&menu);
    while(quitter==0){
    
       switch(indice_ecran){
	 case 0:  afficher_menu(menu,ecran);
                  SDL_Flip(ecran);
                   while (SDL_PollEvent(&event)){

			     switch (event.type)
			 { 
			
				case SDL_QUIT: quitter = 1;
				   break;
                                case SDL_MOUSEBUTTONDOWN:
                                     if (event.button.button==SDL_BUTTON_LEFT){
if(menu.btn_selectionner==5){
  quitter=1;
}
if(menu.btn_selectionner==1){
  indice_ecran=3;
}
if(menu.btn_selectionner==2){
  indice_ecran=2;
}
if(menu.btn_selectionner==3){
  indice_ecran=4;
}
}
				   break;
                               case SDL_KEYDOWN:
                                    if(event.key.keysym.sym==SDLK_DOWN){
                                           menu.btn_selectionner ++;
                                           if(menu.btn_selectionner>5)
                                                menu.btn_selectionner=1;
                                                        
                                        }
                                     if(event.key.keysym.sym==SDLK_UP){
                                           menu.btn_selectionner --;
                                           if(menu.btn_selectionner<1)
                                                menu.btn_selectionner=5;
                                      }
                                     if(event.key.keysym.sym==SDLK_j ||(menu.btn_selectionner==1 && event.key.keysym.sym==SDLK_RETURN)){
                                          indice_ecran=1;  
                                          }
                                     if(event.key.keysym.sym==SDLK_o ||(menu.btn_selectionner==2 && event.key.keysym.sym==SDLK_RETURN)){
                                          indice_ecran=2;  
                                          }
                                     if(event.key.keysym.sym==SDLK_m ||(menu.btn_selectionner==3 && event.key.keysym.sym==SDLK_RETURN)){
                                          indice_ecran=3;  
                                          }
                                   break;
				default:
				   break;
				
			 }



		      }
               miseajour_menu(&menu);
             break;
          case 1://sous menu joueur
              afficher_menu_joueur(menu,ecran);
              SDL_Flip(ecran);
              while (SDL_PollEvent(&event)){

			     switch (event.type)
			 { 
			
				case SDL_QUIT: quitter = 1;
				   break;
                                case SDL_KEYDOWN:
                                    indice_ecran=0;
                                    break;
                                case SDL_MOUSEBUTTONDOWN:
                                    if (event.button.button==SDL_BUTTON_LEFT){
              if(menu.etat_btn_retour==1 && menu.num_page_joueur==0){indice_ecran=0;}else if(menu.etat_btn_retour==1 && menu.num_page_joueur==1){menu.num_page_joueur=0;}


              if(menu.etat_btn_mono==1||menu.etat_btn_multi==1){menu.num_page_joueur=1; 

menu.etat_btn_mono=0;
menu.etat_btn_multi=0;
 }
if(collision_avec_souris(menu.pos_btn_avatar1)==1){
menu.etat_btn_avatar1=1;
menu.etat_btn_avatar2=0;
}else if(collision_avec_souris(menu.pos_btn_avatar2)==1){
menu.etat_btn_avatar1=0;
menu.etat_btn_avatar2=1;
}else if(collision_avec_souris(menu.pos_btn_input1)==1){
menu.etat_btn_input1=1;
menu.etat_btn_input2=0;
}else if(collision_avec_souris(menu.pos_btn_input2)==1){
menu.etat_btn_input1=0;
menu.etat_btn_input2=1;
}

if(menu.etat_btn_valider==1){
indice_ecran=4;
}

}

                                 break;
                          }
                   }
             miseajour_menu_joueur(&menu);
             break;
          case 2://sous menu option
              afficher_menu_option(menu,ecran);
              SDL_Flip(ecran);
              while (SDL_PollEvent(&event)){

			     switch (event.type)
			 { 
			
				case SDL_QUIT: quitter = 1;
				   break;
                                
                                case SDL_MOUSEBUTTONDOWN:
                                    if (event.button.button==SDL_BUTTON_LEFT){
                                           if(collision_avec_souris(menu.pos_retour)==1){indice_ecran=0;}
if(collision_avec_souris(menu.pos_plus)==1){
menu.volume_music +=10;
if(menu.volume_music>100)
   menu.volume_music=100;
}
if(collision_avec_souris(menu.pos_moin)==1){
menu.volume_music -=10;
if(menu.volume_music<0)
   menu.volume_music=0;
}
if(collision_avec_souris(menu.pos_plein)==1 && menu.etat_plein_ecran==0){
     ecran = SDL_SetVideoMode(1920, 1080,  32,SDL_HWSURFACE | SDL_DOUBLEBUF |SDL_FULLSCREEN);
menu.etat_plein_ecran=1;
}
if(collision_avec_souris(menu.pos_normal)==1 && menu.etat_plein_ecran==1){
     ecran = SDL_SetVideoMode(1920, 1080,  32,SDL_HWSURFACE | SDL_DOUBLEBUF);
menu.etat_plein_ecran=0;
}
printf("le volume =%d \n",menu.volume_music);
                                       }
                                   break;
                          }
                   }
             break;
           
           case 3://sous menu sauv
                  afficher_menu_sauv(menu,ecran);
                  SDL_Flip(ecran);
                    
                   while (SDL_PollEvent(&event)){

			     switch (event.type)
			 { 
			
				case SDL_QUIT: quitter = 1;
				   break;
                                case SDL_KEYDOWN:
                                    indice_ecran=0;
                                    if(event.key.keysym.sym==SDLK_n){
                                                indice_ecran=1;
                                                                 }
                                    break;
                                 case SDL_MOUSEBUTTONDOWN:
                                    if (event.button.button==SDL_BUTTON_LEFT){
                                       
                           if(menu.etat_btn_oui==1){menu.num_page_sauv=1;
                                                   }
                                        if(menu.etat_btn_nouvelle==1){indice_ecran=1;}
                                      }
                                  
                                  break;
                          }
                   }





                   miseajour_menu_sauv(&menu);

   
                   break;
          case 4://meilleur score
                afficher_menu_meilleur(menu,ecran);
                SDL_Flip(ecran);
               while (SDL_PollEvent(&event)){

			     switch (event.type)
			 { 
			
				case SDL_QUIT: quitter = 1;
				   break;
                                case SDL_MOUSEBUTTONDOWN:
                                        if(event.button.button==SDL_BUTTON_LEFT){
if(menu.etat_espace_saisie==1){
menu.espace_saisie_actif=1;
}else{menu.espace_saisie_actif=0;}printf("etat actif=%d \n",menu.espace_saisie_actif);
}
                                  break;


                                  case SDL_KEYDOWN:
                                        miseajour_nom_joueur(event,&menu);
                                    break;
                                default:
                                   break;
                          }
          }
           miseajour_menu_meilleur(&menu);
            break;
           default:
              break;
                 }
      
    }

    SDL_FreeSurface(ecran);
    SDL_Quit();




}

