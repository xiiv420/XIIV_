#include <SDL/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL_image.h>
#include<SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <string.h>
#include "fonction.h"
#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600
#define NUMMM_FRAMES 9

int main() {
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
        printf("Erreur SDL: %s\n", SDL_GetError());
        return 1;
    }

    if (TTF_Init() == -1) {
        printf("Erreur SDL_ttf: %s\n", TTF_GetError());
        SDL_Quit(); // Nettoyage en cas d'erreur
        return 1;
    }

    SDL_Surface* screen = SDL_SetVideoMode(800, 600, 32, SDL_SWSURFACE);
    if (!screen) {
        printf("Erreur création écran: %s\n", SDL_GetError());
        TTF_Quit(); // Nettoyage en cas d'erreur
        SDL_Quit();
        return 1;
    }

    // Lancer le jeu
    game(screen);

    // Nettoyage final
    TTF_Quit();
    SDL_Quit();

    return 0;
}

