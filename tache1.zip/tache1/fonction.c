#include "menu.h"

void afficherPage(SDL_Surface *ecran, SDL_Surface *imageBg, SDL_Surface *imageName, SDL_Surface *imageSaisir, SDL_Surface *imageBack, SDL_Surface *imageGo) {
    SDL_Rect posBg = {0, 0};  
    SDL_Rect posName = {ecran->w / 2 - 100, ecran->h / 2 - 100};  
    SDL_Rect posSaisir = {ecran->w / 2 - 100, posName.y + 50}; 
    SDL_Rect posBack = {10, 10};  
    SDL_Rect posGo = {1250,500} ;

    SDL_BlitSurface(imageBg, NULL, ecran, &posBg);
    SDL_BlitSurface(imageName, NULL, ecran, &posName);
    SDL_BlitSurface(imageSaisir, NULL, ecran, &posSaisir);
    SDL_BlitSurface(imageBack, NULL, ecran, &posBack);
    SDL_BlitSurface(imageGo, NULL, ecran, &posGo);
    
    SDL_Flip(ecran);
}

void afficherDeuxiemePage(SDL_Surface *ecran, SDL_Surface *imageBg, SDL_Surface *imageText, SDL_Surface *imageKalb, SDL_Surface *imageSaisir, SDL_Surface *imageBack, SDL_Surface *imageGo) {
    SDL_Rect posBg = {0, 0};  
    SDL_Rect posText = {ecran->w / 2 - 100, ecran->h / 2 - 100};    
    SDL_Rect posSaisir = {posText.x, posText.y + 50};  
    SDL_Rect posKalb = {posSaisir.x - 100, posSaisir.y-20}; 
    SDL_Rect posBack = {10, 10};  
    SDL_Rect posGo = {1250,500} ; 

    SDL_BlitSurface(imageBg, NULL, ecran, &posBg);
    SDL_BlitSurface(imageText, NULL, ecran, &posText);
    SDL_BlitSurface(imageKalb, NULL, ecran, &posKalb);
    SDL_BlitSurface(imageSaisir, NULL, ecran, &posSaisir);
    SDL_BlitSurface(imageBack, NULL, ecran, &posBack);
    SDL_BlitSurface(imageGo, NULL, ecran, &posGo);
    
    SDL_Flip(ecran);
}

