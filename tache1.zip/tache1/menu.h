//Protection du Fichier
#ifndef MENU_H
#define MENU_H

#include <SDL/SDL.h>// pour afficher des graphiques et g�rer les �v�nements 
#include <SDL/SDL_image.h>//charger et afficher des images
#include <SDL/SDL_mixer.h>// jouer des fichiers audio

void afficherPage(SDL_Surface *ecran, SDL_Surface *imageBg, SDL_Surface *imageName, SDL_Surface *imageSaisir, SDL_Surface *imageBack, SDL_Surface *imageGo);
void afficherDeuxiemePage(SDL_Surface *ecran, SDL_Surface *imageBg, SDL_Surface *imageText, SDL_Surface *imageKalb, SDL_Surface *imageSaisir, SDL_Surface *imageBack, SDL_Surface *imageGo);
//fermer protection
#endif


