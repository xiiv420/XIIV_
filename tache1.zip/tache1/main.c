#include "menu.h"

int main(int argc, char** argv) {
//ecran → La fenêtre où on affiche le jeu.
//imageBg, imageName, imageSaisir ... → Les images utilisées dans l'interface.
//event → Stocke les événements (clavier, souris, etc.).
//musique → Stocke la musique.
//quitter = 1 → Tant que quitter = 1, le jeu continue.
//page = 1 → Indique quelle page afficher (1 = première page, 2 = deuxième)
    SDL_Surface *ecran, *imageBg, *imageName, *imageSaisir, *imageBack, *imageGo, *imageText,*imageKalb;
    SDL_Event event;
    Mix_Music *musique;
    int quitter = 1, page = 1;

    // Initialisation de SDL et SDL_mixer son
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER) < 0) return -1;
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 1024) < 0) return -1;

    // Création de la fenêtre 
    ecran = SDL_SetVideoMode(1360, 604, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    if (!ecran) return -1;

    // Chargement des images
    imageBg = IMG_Load("/home/roua/Desktop/game/tache1/Fichier 1.png");
    imageName = IMG_Load("name.png");
    imageSaisir = IMG_Load("saisir.jpg");
    imageBack = IMG_Load("back.jpg");
    imageGo = IMG_Load("go.jpg");
    imageText = IMG_Load("text.png");
    imageKalb = IMG_Load("kalb.png");

    if (!imageBg || !imageName || !imageSaisir || !imageBack || !imageGo || !imageText || !imageKalb) return -1;

    // Chargement et lecture de la musique
    musique = Mix_LoadMUS("soundtrack_1.mp3");
    if (musique) Mix_PlayMusic(musique, -1);

    // Boucle principale
    while (quitter) {
        // Affichage de la page en fonction de la valeur de `page`
        if (page == 1)
            afficherPage(ecran, imageBg, imageName, imageSaisir, imageBack, imageGo);
        else
            afficherDeuxiemePage(ecran, imageBg, imageText, imageKalb, imageSaisir, imageBack, imageGo);

        // Gestion des événements
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_QUIT:
                    quitter = 0;
                    break;

                case SDL_KEYDOWN:
                    if (event.key.keysym.sym == SDLK_ESCAPE) quitter = 0;
                    break;

                case SDL_MOUSEBUTTONDOWN:
                    if (event.button.button == SDL_BUTTON_LEFT) {
                        int x = event.button.x, y = event.button.y;

                        // Bouton "Go" (aller à la deuxième page)
                        if (x >= 1250 && x <= 1250 + imageGo->w && y >= 500 && y <= 500 + imageGo->h) {
                            printf("Clic sur GO détecté ! Passage à la deuxième page...\n");
                            page = 2;
                        }

                        // Bouton "Back" (retour à la première page)
                        if (x >= 10 && x <= 10 + imageBack->w && y >= 10 && y <= 10 + imageBack->h) {
                            printf("Clic sur BACK détecté ! Retour à la première page...\n");
                            page = 1;
                        }
                    }
                    break;
            }
        }
    }

    // Libération de la mémoire
    SDL_FreeSurface(imageBg);
    SDL_FreeSurface(imageName);
    SDL_FreeSurface(imageSaisir);
    SDL_FreeSurface(imageBack);
    SDL_FreeSurface(imageGo);
    SDL_FreeSurface(imageText);
    SDL_FreeSurface(imageKalb);
    Mix_FreeMusic(musique);
    Mix_CloseAudio();
    SDL_Quit();

    return 0;
}

