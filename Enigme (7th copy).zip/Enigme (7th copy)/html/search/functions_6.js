var searchData=
[
  ['resolution_5fenigme',['resolution_enigme',['../enigme_8c.html#a7e694427ecb29fa239e0d3799052c181',1,'resolution_enigme(SDL_Surface *screen, SDL_Surface *background, enigme *e, int *score, Mix_Chunk *win, Mix_Chunk *lose, Mix_Chunk *clickSound):&#160;enigme.c'],['../enigme_8h.html#a7e694427ecb29fa239e0d3799052c181',1,'resolution_enigme(SDL_Surface *screen, SDL_Surface *background, enigme *e, int *score, Mix_Chunk *win, Mix_Chunk *lose, Mix_Chunk *clickSound):&#160;enigme.c']]]
];
