var searchData=
[
  ['max_5fquestions',['MAX_QUESTIONS',['../enigme_8h.html#ab6b144f45d1f86ecd20ac04dde390430',1,'enigme.h']]]
];
