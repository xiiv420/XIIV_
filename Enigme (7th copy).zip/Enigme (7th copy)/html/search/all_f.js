var searchData=
[
  ['tempsactuel',['tempsActuel',['../structenigme.html#a7e307e772db2c45d9d43e37aababf5db',1,'enigme']]],
  ['tempsprecedent',['tempsPrecedent',['../structenigme.html#aac16fe529fd0abbbc0a160a9f1d3b97f',1,'enigme']]],
  ['textcolor',['textColor',['../structenigme.html#a5ad688c5df19e7b9df95ec4370d158c9',1,'enigme']]]
];
