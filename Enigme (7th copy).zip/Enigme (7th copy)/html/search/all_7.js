var searchData=
[
  ['init_5fenigme',['Init_Enigme',['../enigme_8c.html#a3cd496ac4b828eddb71bb6ca005d24ee',1,'Init_Enigme(enigme *e):&#160;enigme.c'],['../enigme_8h.html#a3cd496ac4b828eddb71bb6ca005d24ee',1,'Init_Enigme(enigme *e):&#160;enigme.c']]]
];
