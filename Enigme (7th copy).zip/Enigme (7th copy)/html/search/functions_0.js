var searchData=
[
  ['afficher_5fmessage',['afficher_message',['../enigme_8c.html#aa279ecc572abfb8512d288b88abd75ac',1,'afficher_message(SDL_Surface *screen, SDL_Surface *background, char *texte_a_afficher, SDL_Color couleur, Mix_Chunk *sound):&#160;enigme.c'],['../enigme_8h.html#aa279ecc572abfb8512d288b88abd75ac',1,'afficher_message(SDL_Surface *screen, SDL_Surface *background, char *texte_a_afficher, SDL_Color couleur, Mix_Chunk *sound):&#160;enigme.c']]],
  ['afficher_5ftimer',['afficher_timer',['../enigme_8c.html#a9d6f49c759d9a4a4cf12f8745e4c7c0c',1,'afficher_timer(SDL_Surface *screen, enigme *e):&#160;enigme.c'],['../enigme_8h.html#a9d6f49c759d9a4a4cf12f8745e4c7c0c',1,'afficher_timer(SDL_Surface *screen, enigme *e):&#160;enigme.c']]],
  ['afficherenigme',['Afficherenigme',['../enigme_8c.html#af8e29b63a89b3452a39465a1335a1fe4',1,'Afficherenigme(enigme *e, SDL_Surface *screen):&#160;enigme.c'],['../enigme_8h.html#af8e29b63a89b3452a39465a1335a1fe4',1,'Afficherenigme(enigme *e, SDL_Surface *screen):&#160;enigme.c']]]
];
