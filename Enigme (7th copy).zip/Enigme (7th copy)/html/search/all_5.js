var searchData=
[
  ['font',['font',['../structenigme.html#a3df99e502f9fbcc8a0228e916256e481',1,'enigme']]]
];
