var menudata={children:[
{text:"Page principale",url:"index.html"},
{text:"Structures de données",url:"annotated.html",children:[
{text:"Structures de données",url:"annotated.html"},
{text:"Index des structures de données",url:"classes.html"},
{text:"Champs de donnée",url:"functions.html",children:[
{text:"Tout",url:"functions.html"},
{text:"Variables",url:"functions_vars.html"}]}]},
{text:"Fichiers",url:"files.html",children:[
{text:"Liste des fichiers",url:"files.html"},
{text:"Variables globale",url:"globals.html",children:[
{text:"Tout",url:"globals.html"},
{text:"Fonctions",url:"globals_func.html"},
{text:"Macros",url:"globals_defs.html"}]}]}]}
