#include "menu.h"

void AfficherBackground(Background *bg, SDL_Surface *screen, int multiplayer) {
    if (!multiplayer) {
        SDL_BlitSurface(bg->image, &bg->camera_pos, screen, NULL);
    } else {
        SDL_Rect pos1 = {0, 0};
        SDL_Rect pos2 = {0, SCREEN_HEIGHT / 2};
        SDL_BlitSurface(bg->image, &bg->camera_pos, screen, &pos1);
        SDL_BlitSurface(bg->image, &bg->camera_pos2, screen, &pos2);
    }
}

void initSDL(SDL_Surface **screen, SDL_Surface **backgrounds, SDL_Surface **masques, TTF_Font **font, time_t *start_time) {
    SDL_Init(SDL_INIT_VIDEO);
    TTF_Init();
    *screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 32, SDL_SWSURFACE);
    backgrounds[0] = SDL_LoadBMP("ther.bmp");
    backgrounds[1] = SDL_LoadBMP("level2.bmp");
    masques[0] = SDL_LoadBMP("therr.bmp");
    masques[1] = SDL_LoadBMP("level2Mask.bmp");
    *font = TTF_OpenFont("font.ttf", 24);
    *start_time = time(NULL);
}

void handleInput(SDL_Event *event, int *running, int *level, int *multiplayer, int *show_help) {
    while (SDL_PollEvent(event)) {
        if (event->type == SDL_QUIT) {
            *running = 0;
        } 
        else if (event->type == SDL_KEYDOWN) {
            SDLKey key = event->key.keysym.sym;

            if (key == SDLK_ESCAPE || key == SDLK_SPACE) {
                *running = 0; // quitter si ESC ou ESPACE
            } else if (key == SDLK_1) {
                *level = 1;
            } else if (key == SDLK_2) {
                *level = 2;
            } else if (key == SDLK_h) {
                *show_help = !(*show_help);
            }
        }
    }
}

void update(SDL_Rect *camera1, SDL_Rect *camera2, SDL_Surface **backgrounds, int multiplayer) {
    const Uint8 *keystate = SDL_GetKeyState(NULL);
    int max_x = backgrounds[0]->w - SCREEN_WIDTH;
    int max_y = backgrounds[0]->h - (multiplayer ? SCREEN_HEIGHT / 2 : SCREEN_HEIGHT);

    if (!multiplayer) {
        if (keystate[SDLK_LEFT] && camera1->x > 0) camera1->x -= SCROLL_SPEED;
        if (keystate[SDLK_RIGHT] && camera1->x < max_x) camera1->x += SCROLL_SPEED;
        if (keystate[SDLK_UP] && camera1->y > 0) camera1->y -= SCROLL_SPEED;
        if (keystate[SDLK_DOWN] && camera1->y < max_y) camera1->y += SCROLL_SPEED;
    } else {
        if (keystate[SDLK_q] && camera1->x > 0) camera1->x -= SCROLL_SPEED;
        if (keystate[SDLK_d] && camera1->x < max_x) camera1->x += SCROLL_SPEED;
        if (keystate[SDLK_z] && camera1->y > 0) camera1->y -= SCROLL_SPEED;
        if (keystate[SDLK_s] && camera1->y < max_y) camera1->y += SCROLL_SPEED;

        if (keystate[SDLK_LEFT] && camera2->x > 0) camera2->x -= SCROLL_SPEED;
        if (keystate[SDLK_RIGHT] && camera2->x < max_x) camera2->x += SCROLL_SPEED;
        if (keystate[SDLK_UP] && camera2->y > 0) camera2->y -= SCROLL_SPEED;
        if (keystate[SDLK_DOWN] && camera2->y < max_y) camera2->y += SCROLL_SPEED;
    }
}

void afficherTemps(SDL_Surface *screen, TTF_Font *font, SDL_Color color, time_t start_time) {
    time_t now = time(NULL);
    int elapsed = (int)difftime(now, start_time);
    int h = elapsed / 3600;
    int m = (elapsed % 3600) / 60;
    int s = elapsed % 60;

    char buffer[50];
    sprintf(buffer, "Temps: %02d:%02d:%02d", h, m, s);

    SDL_Surface *text = TTF_RenderText_Solid(font, buffer, color);
    SDL_Rect pos = {10, 10};
    SDL_BlitSurface(text, NULL, screen, &pos);
    SDL_FreeSurface(text);
}

void afficherAide(SDL_Surface *screen, TTF_Font *font, SDL_Color color) {
    const char *instructions[] = {
        "Touches joueur 1 : ZQSD",
        "Touches joueur 2 : Fleches",
        "1 ou 2 : Changer de niveau",
        "H : Afficher / Cacher aide",
        "ESC : Quitter"
    };

    SDL_Rect pos = {220, 200};
    for (int i = 0; i < 5; ++i) {
        SDL_Surface *text = TTF_RenderText_Solid(font, instructions[i], color);
        SDL_BlitSurface(text, NULL, screen, &pos);
        pos.y += 30;
        SDL_FreeSurface(text);
    }
}

void render(SDL_Surface *screen, SDL_Surface **backgrounds, TTF_Font *font, int level, int multiplayer, SDL_Rect *camera1, SDL_Rect *camera2, SDL_Color textColor, time_t start_time, int show_help) {
    Background bg;
    bg.image = backgrounds[level - 1];
    bg.camera_pos = *camera1;
    bg.camera_pos2 = *camera2;

    AfficherBackground(&bg, screen, multiplayer);
    afficherTemps(screen, font, textColor, start_time);

    if (show_help) afficherAide(screen, font, textColor);

    SDL_Flip(screen);
}

void cleanUp(SDL_Surface **backgrounds, SDL_Surface **masques, TTF_Font *font) {
    SDL_FreeSurface(backgrounds[0]);
    SDL_FreeSurface(backgrounds[1]);
    SDL_FreeSurface(masques[0]);
    SDL_FreeSurface(masques[1]);
    TTF_CloseFont(font);
    TTF_Quit();
    SDL_Quit();
}

SDL_Color GetPixel(SDL_Surface *pSurface, int x, int y) {
    SDL_Color color;
    Uint32 col = 0;
    char* pPosition = (char*) pSurface->pixels;
    pPosition += (pSurface->pitch * y);
    pPosition += (pSurface->format->BytesPerPixel * x);
    memcpy(&col, pPosition, pSurface->format->BytesPerPixel);
    SDL_GetRGB(col, pSurface->format, &color.r, &color.g, &color.b);
    return color;
}

int CollisionParfaite(SDL_Surface *masque, SDL_Rect posPerso) {
    SDL_Color color;
    int X = posPerso.x, Y = posPerso.y, W = posPerso.w, H = posPerso.h;
    int points[8][2] = {
        {X, Y}, {X + W / 2, Y}, {X + W, Y},
        {X, Y + H / 2}, {X, Y + H},
        {X + W / 2, Y + H}, {X + W, Y + H}, {X + W, Y + H / 2}
    };
    for (int i = 0; i < 8; ++i) {
        if (points[i][0] >= 0 && points[i][1] >= 0 && points[i][0] < masque->w && points[i][1] < masque->h) {
            color = GetPixel(masque, points[i][0], points[i][1]);
            if (color.r == 0 && color.g == 0 && color.b == 0) return 1;
        }
    }
    return 0;
}
