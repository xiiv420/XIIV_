#ifndef MENU_H
#define MENU_H

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600
#define SCROLL_SPEED 5

typedef struct {
    SDL_Surface *image;
    SDL_Rect camera_pos;
    SDL_Rect camera_pos2;
} Background;

void initSDL(SDL_Surface **screen, SDL_Surface **backgrounds, SDL_Surface **masques, TTF_Font **font, time_t *start_time);
void handleInput(SDL_Event *event, int *running, int *level, int *multiplayer, int *show_help);
void update(SDL_Rect *camera1, SDL_Rect *camera2, SDL_Surface **backgrounds, int multiplayer);
void render(SDL_Surface *screen, SDL_Surface **backgrounds, TTF_Font *font, int level, int multiplayer, SDL_Rect *camera1, SDL_Rect *camera2, SDL_Color textColor, time_t start_time, int show_help);
void cleanUp(SDL_Surface **backgrounds, SDL_Surface **masques, TTF_Font *font);
void AfficherBackground(Background *bg, SDL_Surface *screen, int multiplayer);
void afficherTemps(SDL_Surface *screen, TTF_Font *font, SDL_Color color, time_t start_time);
void afficherAide(SDL_Surface *screen, TTF_Font *font, SDL_Color color);
SDL_Color GetPixel(SDL_Surface *pSurface, int x, int y);
int CollisionParfaite(SDL_Surface *masque, SDL_Rect posPerso);

#endif

