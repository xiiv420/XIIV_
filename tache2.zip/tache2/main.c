#include "menu.h"

int main() {
    SDL_Event event;
    int running = 1, level = 1, multiplayer = 0, show_help = 0;
    SDL_Surface *screen = NULL;
    SDL_Surface *backgrounds[2] = {NULL, NULL};
    SDL_Surface *masques[2] = {NULL, NULL};
    TTF_Font *font = NULL;
    SDL_Color textColor = {255, 255, 255};
    SDL_Rect camera1 = {0, 0, SCREEN_WIDTH, SCREEN_HEIGHT};
    SDL_Rect camera2 = {0, SCREEN_HEIGHT / 2, SCREEN_WIDTH, SCREEN_HEIGHT / 2};
    time_t start_time;

    printf("Choisir mode : 1 pour solo, 2 pour multijoueur : ");
    int choix;
    scanf("%d", &choix);

    if (choix == 2) {
        multiplayer = 1;
        camera1.h = SCREEN_HEIGHT / 2;
        camera2.h = SCREEN_HEIGHT / 2;
    }

    initSDL(&screen, backgrounds, masques, &font, &start_time);

    while (running) {
        handleInput(&event, &running, &level, &multiplayer, &show_help);
        update(&camera1, &camera2, backgrounds, multiplayer);

        //Exemple de perso fictif pour collision
        SDL_Rect posperso = { camera1.x + 100, camera1.y + 100, 32, 32 };
        if (CollisionParfaite(masques[level - 1], posperso)) {
            printf("Collision detectee !\n");
        }

        render(screen, backgrounds, font, level, multiplayer, &camera1, &camera2, textColor, start_time, show_help);
        SDL_Delay(16);
    }

    cleanUp(backgrounds, masques, font);
    return 0;
}

